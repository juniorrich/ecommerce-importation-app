const express = require('express');
const {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  deleteProductImage,
  getCategories,
} = require('../controllers/productController');
const { protect, authorize } = require('../middleware/auth');
const { upload } = require('../middleware/upload');

const router = express.Router();

router.route('/categories/list').get(getCategories);

router
  .route('/')
  .get(getProducts)
  .post(
    protect,
    authorize('admin'),
    upload.array('images', 5), // max 5 images
    createProduct
  );

router
  .route('/:id')
  .get(getProduct)
  .put(
    protect,
    authorize('admin'),
    upload.array('images', 5),
    updateProduct
  )
  .delete(protect, authorize('admin'), deleteProduct);

// Delete a specific image from a product
router.delete(
  '/:id/images/:publicId',
  protect,
  authorize('admin'),
  deleteProductImage
);

module.exports = router;
